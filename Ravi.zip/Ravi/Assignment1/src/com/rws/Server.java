/**
 * 
 */
package com.rws;

import java.util.Date;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

/**
 * @author Saurabh
 *
 */
@Path("/result")
public class Server {

	int input1 = 10;
	int input2 = 12;

	@GET
	@Produces(MediaType.TEXT_XML)
	public String sayXMLHello() {
		int sum = input1 + input2;
		return "<?xml version=\"1.0\"?>" + "<Sum of the two numbers are>: " + sum;
	}

	@GET
	@Path("/add")
	public Response addNumbers(@PathParam("num1") int num1, @PathParam("num2") int num2) {
		return Response.status(200).entity(num1 + num2).build();

	}

}
