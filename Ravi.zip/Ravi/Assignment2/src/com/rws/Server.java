/**
 * 
 */
package com.rws;

import java.util.Date;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 * @author Saurabh
 *
 */
@Path("/datetime")
public class Server {
	
	Date date=new Date();
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	public String sendServerDateTime() {
		return "Server Date and Time is " + date;
	}
	@GET
	@Produces(MediaType.TEXT_XML)
	public String sayXMLHello() {
		return "<?xml version=\"1.0\"?>" + "<DateTime>: " + System.currentTimeMillis();
	}
	
	@GET
	@Produces(MediaType.TEXT_HTML)
	public String sayHtmlHello() {
		return "<html> " + "<title>" + "Date Time: "
				+"</title>" + "<body><h1>" + System.currentTimeMillis()
				+"</body></h1>" + "</html>";
	}

}
