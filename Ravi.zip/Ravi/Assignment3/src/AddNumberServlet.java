

import java.io.IOException;
import java.io.PrintWriter;
import java.net.URI;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.UriBuilder;

import org.glassfish.jersey.client.ClientConfig;

/**
 * Servlet implementation class AddNumberServlet
 */
@WebServlet("/AddNumberServlet")
public class AddNumberServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static final String webServiceURI = "http://localhost:8082/Assignment3";  
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddNumberServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");  
	    PrintWriter out = response.getWriter();  
	          
	    String n=request.getParameter("input1");  
	    String p=request.getParameter("input2");
	    
	    int input1=Integer.parseInt(n);
	    int input2=Integer.parseInt(p);
	    
	    ClientConfig clientConfig = new ClientConfig();
		Client client = ClientBuilder.newClient(clientConfig);
		URI serviceURI = UriBuilder.fromUri(webServiceURI).build();
		WebTarget webTarget = client.target(serviceURI);
		
		System.out.println(webTarget.path("result").request().accept(MediaType.TEXT_HTML).get(String.class));
		
	    
	    RequestDispatcher rd=request.getRequestDispatcher("/index.html");
        rd.include(request, response); 
        out.println("The sum of above numbers are:");
        out.print(webTarget.path("result").request().accept(MediaType.TEXT_HTML).get(String.class)); 
	
	}

}
