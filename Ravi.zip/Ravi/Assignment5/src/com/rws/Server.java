/**
 * 
 */
package com.rws;


import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;


/**
 * @author Saurabh
 *
 */
@Path("/result")
public class Server {
	
	int input1=10;
	int input2=12;

	@GET
	@Produces(MediaType.TEXT_XML)
	public String sayXMLHello() {
		int sum=input1+input2;
		return "<?xml version=\"1.0\"?>" + "<Sum of the two numbers are>: " + sum;
	}
	@GET
    @Path("{input1}/{input2}")
    @Produces(MediaType.TEXT_XML)
    public String getResultByUsingPathParam(
                    @PathParam("input1") int input1,
                    @PathParam("input2") int input2) {
		int sum=input1+input2;
		return "<?xml version=\"1.0\"?>" + "<Sum of the two numbers are>: " + sum;       
    }
	@GET
	@Path("/query")
    @Produces(MediaType.TEXT_XML)
    public String getResultByUsingQueryParam(
                    @QueryParam("input1") int input1,
                    @QueryParam("input2") int input2) {
		int sum=input1+input2;
		return "<?xml version=\"1.0\"?>" + "<Sum of the two numbers are>: " + sum;       
    }
	
	@GET
	@Path("/matrix")
    @Produces(MediaType.TEXT_XML)
    public String getResultByUsingMetrixParam(
                    @MatrixParam("input1") int input1,
                    @MatrixParam("input2") int input2) {
		int sum=input1+input2;
		return "<?xml version=\"1.0\"?>" + "<Sum of the two numbers are>: " + sum;       
    }
}
