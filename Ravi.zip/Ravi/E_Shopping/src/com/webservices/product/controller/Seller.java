package com.webservices.controller;

import java.util.List;

import javax.ws.rs.BeanParam;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.MediaType;


import com.product.bean.ProductFilterBean;
import com.product.entity.Product;
import com.product.service.buyerService;
import com.product.service.sellerService;


@Path("/seller")
public class Seller {
	
    sellerService ss=new sellerService();
    buyerService bs=new  buyerService();
	
    @GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Product> getProduct(@BeanParam ProductFilterBean filterBean)
	{
	
		
		if(filterBean.getStarting_price()>=0 && filterBean.getLast_price()>0)
		{
			return bs.getAllProductPaginated(filterBean.getStarting_price(), filterBean.getLast_price());
		}
		return bs.getAllProducts();
	}	
	
	@POST
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public Product addProduct(Product product)
	{
		return ss.addProduct(product);
	}
	@PUT
	@Path("/{productId}")
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.APPLICATION_XML)
	public Product updateProduct(@PathParam("productId") long id,Product product)
	{
		return ss.updateProduct(product,id);
	}
	
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{productId}")
	public void removeMessage( @PathParam("productId") long id)
	{
		 ss.removeMesssage(id);
	}
	
	  /* private Client client;
	   private String REST_SERVICE_URL = "http://localhost:8080/Electronics_Products_Shopping/webapi/SellerService/addProducts";
	   private static final String SUCCESS_RESULT="<result>success</result>";
	   private static final String PASS = "pass";
	   private static final String FAIL = "fail";

	   private void init(){
	      this.client = ClientBuilder.newClient();
	   }
	
	   private void addProduct(){
		   
	      Form form = new Form();
	      form.param("product_name", "SONY_Led-52");
	      form.param("category_name", "Television");
	      form.param("price", "80000");
	      form.param("stock", "4");
	      form.param("remarks", "verygood");

	      String callResult = client
	         .target(REST_SERVICE_URL)
	         .request(MediaType.APPLICATION_XML)
	         .post(Entity.entity(form,
	            MediaType.APPLICATION_FORM_URLENCODED_TYPE),
	            String.class);
	   
	      String result = PASS;
	      if(!SUCCESS_RESULT.equals(callResult)){
	         result = FAIL;
	      }

	      System.out.println("addProduct, Result: " + result );
	   }
	   
	   private void updateProduct(){
		   Form form = new Form();
		   form.param("product_name", "DELL Inspiron");
		   form.param("category_name", "Laptop");
		   form.param("price", "40000");
		   form.param("stock", "7");
		   form.param("remarks", "awesome");
		   
		   
	   }
	  
	
	public static void main(String args[])
	{
		Seller seller = new Seller();
		seller.init();
		seller.addProduct();
		
	}  */
	 
	}
