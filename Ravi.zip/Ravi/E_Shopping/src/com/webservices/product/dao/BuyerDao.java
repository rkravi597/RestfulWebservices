package com.product.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.product.entity.Product;

public class BuyerDao {

	public List<Product> getAllProducts() {

		List<Product> products = new ArrayList<Product>();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");//
		@SuppressWarnings("deprecation")
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Criteria criteria = session.createCriteria(Product.class);
		products = (List<Product>) criteria.list();
		return products;
	}


	public List<Product> getAllProductsforSpecificCategory(String name) {
		List<Product> products = new ArrayList<Product>();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");//
		@SuppressWarnings("deprecation")
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Product product=new Product();
		Query query = session.createQuery("from Product where category_name= :cname");
	    query.setString("cname", name);
		products = (List<Product>) query.list();
		return products;
	}


	public List<Product> getAllProductsPaginatedWithPrice(long l, long m) {
		List<Product> products = new ArrayList<Product>();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");//
		@SuppressWarnings("deprecation")
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Product product=new Product();
		Query query = session.createQuery("from Product where price>= :pstart and price<= :plast");
	    query.setLong("pstart", l);
	    query.setLong("plast", m);
		products = (List<Product>) query.list();
		Iterator iterator = products.iterator();
		
		while (iterator.hasNext()) {
			Product p = (Product) iterator.next();
			System.out.println(p.getProduct_name());
			System.out.println(p.getCategory_name());
			System.out.println(p.getPrice());
		}
		return products;
	}


	public int buyProducts(long id) {
		List<Product> products = new ArrayList<Product>();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");//
		@SuppressWarnings("deprecation")
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("select count(stock) from Product where id= :pid");
	    query.setLong("pid", id);
	    Long count = (Long)query.uniqueResult();
        Query qry = session.createQuery("update Product set stock= :pstock where id= :pid");
        qry.setLong("pid", id);
        qry.setLong("pstock", count-1);
        int res = qry.executeUpdate();

		return res;
	}
	
	

}
