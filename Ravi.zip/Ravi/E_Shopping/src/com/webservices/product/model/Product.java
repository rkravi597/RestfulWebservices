package com.product.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
@XmlRootElement(name = "product")
@Entity
@Table(name="product_details")
public class Product {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Column(name = "id", updatable = false, nullable = false)
	private Long id;
	@Column(name="product_name")
	private String product_name;
	@Column(name="category_name")
	private String category_name;
	@Column(name="price")
	private double price;
	@Column(name="stock")
	private long stock;
	@Column(name="remarks")
	private String remarks;
	
	
	
	public Product() {
		super();
	}
	public Product(String product_name, String category_name, double price, long stock, String remarks) {
		super();
		this.product_name = product_name;
		this.category_name = category_name;
		this.price = price;
		this.stock = stock;
		this.remarks = remarks;
	}
	
	public Long getId() {
		return id;
	}
	@XmlElement
	public void setId(Long id) {
		this.id = id;
	}
	public String getProduct_name() {
		return product_name;
	}
	@XmlElement
	public void setProduct_name(String product_name) {
		this.product_name = product_name;
	}
	public String getCategory_name() {
		return category_name;
	}
	@XmlElement
	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}
	public double getPrice() {
		return price;
	}
	@XmlElement
	public void setPrice(double price) {
		this.price = price;
	}
	public long getStock() {
		return stock;
	}
	public void setStock(long stock) {
		this.stock = stock;
	}
	public String getRemarks() {
		return remarks;
	}
	@XmlElement
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	
	
}
