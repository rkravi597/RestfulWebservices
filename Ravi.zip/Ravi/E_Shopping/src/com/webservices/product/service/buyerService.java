package com.product.service;

import java.util.ArrayList;
import java.util.List;

import com.product.dao.BuyerDao;
import com.product.entity.Product;

public class buyerService {

	BuyerDao buyerDao=new BuyerDao();
	public List<Product> getAllProducts() {
		
		List<Product> products=new ArrayList<Product>();
		products=buyerDao.getAllProducts();
		return products;
	}
	 public List<Product> getProducts(String name) {
		List<Product> products=new ArrayList<Product>();
		products=buyerDao.getAllProductsforSpecificCategory(name);
		return products;
	}
	public List<Product> getAllProductPaginated(long l, long m) 
	{
		List<Product> products=new ArrayList<Product>();
		products=buyerDao.getAllProductsPaginatedWithPrice(l,m);
		return products;
	}
	
	public int buyProducts(long id) {
		
		int res=buyerDao.buyProducts(id);
			
		return res;
	}

}
