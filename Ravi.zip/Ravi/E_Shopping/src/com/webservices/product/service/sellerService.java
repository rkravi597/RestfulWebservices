package com.product.service;

import java.io.IOException;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.product.dao.SellerDao;
import com.product.entity.Product;

//@Path("/{SellerService}")
public class sellerService {
	
	SellerDao sd= new SellerDao();
/*@POST
@Path("/{addProducts}")
@Produces(MediaType.APPLICATION_XML)
@Consumes(MediaType.APPLICATION_FORM_URLENCODED)

	public long addProduct(
			@FormParam("product_name") String product_name,
			@FormParam("category_name") String category_name,
			@FormParam("price") Double price,
	        @FormParam("stock") Long stock,
	        @FormParam("remarks") String remarks) throws IOException
{
	System.out.println("Inside seller service");	
	Product product=new Product(product_name,category_name,price,stock,remarks);
		  
		long id= sd.addProduct(product);
		
		if(id>0)
		{
			System.out.println("successfully  product saved");
		}
		else
		{
			System.out.println("oops somethings went wrong");
		}
		return id;
		
		
	}*/
public Product addProduct(Product product) {
	
	long id= sd.addProduct(product);
	
	if(id>0)
	{
		System.out.println("successfully  product saved");
	}
	else
	{
		System.out.println("oops somethings went wrong");
	}
	return product;
}
public Product updateProduct(Product product, long pid) {
	
   long id= sd.updateProduct(product,pid);
	
	if(id>0)
	{
		System.out.println("successfully  product updated");
	}
	else
	{
		System.out.println("oops somethings went wrong");
	}
	return product;
}
public void removeMesssage(long id) {
	 int res= sd.removeProduct(id);
		
		if(res>0)
		{
			System.out.println("successfully  product removed");
		}
		else
		{
			System.out.println("oops somethings went wrong");
		}
	
}

}
