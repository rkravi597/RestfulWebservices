package com.product.bean;

import javax.ws.rs.QueryParam;

public class ProductsFilterBean {

	private  @QueryParam("starting_price") long starting_price;
	private  @QueryParam("last_price") long last_price; 
	   
	   public long getStarting_price() {
		return starting_price;
	}
	public void setStarting_price(long starting_price) {
		this.starting_price = starting_price;
	}
	public long getLast_price() {
		return last_price;
	}
	public void setLast_price(long last_price) {
		this.last_price = last_price;
	}

}
