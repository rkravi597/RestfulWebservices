package com.product.controller;


import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;

import com.product.entity.Products;



public class Buyer {

	private Client client;
	   private String REST_SERVICE_URL = "http://localhost:8080/Electronics_Product_Shopping/webapi/BuyerService/buyers";
	   private static final String SUCCESS_RESULT="<result>success</result>";
	   private static final String PASS = "pass";
	   private static final String FAIL = "fail";

	   private void init(){
	      this.client = ClientBuilder.newClient();
	   }
	   public static void main(String[] args){
		   Buyer buyer = new Buyer();
		   buyer.init();

		   buyer.getAllProducts();
		   buyer.getAllProductsBasedOnCategory();
	       buyer.getAllProductsBasedOnPriceRange();
		   buyer.buyProduct();
		   }
	private void buyProduct() {
		
		  Form form = new Form();
	      form.param("product_name", "SONY_Led-52");
	      form.param("category_name", "Television");
	      form.param("price", "80000");
	      form.param("stock", "4");
	      form.param("remarks", "verygood");
	      form.param("id", "5");
	      
		String callResult = client
		         .target(REST_SERVICE_URL)
		         .request(MediaType.APPLICATION_XML)
		         .put(Entity.entity(form,
		                 MediaType.APPLICATION_FORM_URLENCODED_TYPE),
		                 String.class);;

		      String result = PASS;
		      if(!SUCCESS_RESULT.equals(callResult)){
		         result = PASS;
		      }

		      System.out.println("Test case name: testBuyProduct, Result: " + result );
		      System.out.println("\n");
		   }
		
	private void getAllProductsBasedOnPriceRange() {
		GenericType<List<Products>> list = new GenericType<List<Products>>() {};
	      List<Products> products = client
	         .target(REST_SERVICE_URL)
	         .path("/{price1}/{price2}")
	         .resolveTemplate("price1", 500)
	         .resolveTemplate("price2", 20000)
	         .request(MediaType.APPLICATION_XML)
	         .get(list);
	      String result = PASS;
	      if(products.isEmpty()){
	         result = FAIL;
	      }
	      
	      System.out.println("Please find below  All Products Details based on priceRange");
	      System.out.print("\n");
	      for(Products pro:products)
	      {
	    	  System.out.println(pro);
	      }
	      System.out.println("Test case name: testGetAllProductsBasedOnPriceRange, Result: " + result );	
	      System.out.println("\n");
		
	}
	private void getAllProductsBasedOnCategory() {
	     GenericType<List<Products>> list = new GenericType<List<Products>>() {};
	      List<Products> products = client
	         .target(REST_SERVICE_URL)
	         .path("/{category}")
	         .resolveTemplate("category", "TV")
	         .request(MediaType.APPLICATION_XML)
	         .get(list);
	      String result = PASS;
	      if(products.isEmpty()){
	         result = FAIL;
	      }
	     
	      System.out.println("Please find below  All Products Details based on category");
	      System.out.print("\n");
	      for(Products pro:products)
	      {
	    	  System.out.println(pro);
	      }
	      System.out.println("Test case name: testGetAllProductsBasedOnCategory, Result: " + result );
	      System.out.println("\n");
	}
	
	private void getAllProducts() {
	
	     GenericType<List<Products>> list = new GenericType<List<Products>>() {};
	      List<Products> products = client
	         .target(REST_SERVICE_URL)
	         .request(MediaType.APPLICATION_XML)
	         .get(list);
	      String result = PASS;
	      if(products.isEmpty()){
	         result = FAIL;
	      }
	      
	      System.out.println("Please find below  All Products Details");
	      System.out.println("");
	      for(Products usr:products)
	      {
	    	  System.out.println(usr);
	      }
	      System.out.println("Test case name: testGetAllProducts, Result: " + result );
	      System.out.println("\n");
	}
	
}
