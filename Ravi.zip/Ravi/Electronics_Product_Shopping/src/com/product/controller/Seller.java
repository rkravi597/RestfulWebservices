package com.product.controller;

import java.util.List;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Form;
import javax.ws.rs.core.GenericType;
import javax.ws.rs.core.MediaType;

import com.product.entity.Products;


public class Seller {
	
	   private Client client;
	   private String REST_SERVICE_URL = "http://localhost:8080/Electronics_Product_Shopping/webapi/SellerService/products";
	   private static final String SUCCESS_RESULT="<result>success</result>";
	   private static final String PASS = "pass";
	   private static final String FAIL = "fail";

	   private void init(){
	      this.client = ClientBuilder.newClient();
	   }
	
	
	public static void main(String args[])
	{
		Seller seller = new Seller();
		seller.init();
		seller.addProduct();
		seller.updateProduct();
		seller.getAllProducts();
		seller.deleteProduct();
		
	}  

	
	   private void deleteProduct() {
     
		   String callResult = client
			         .target(REST_SERVICE_URL)
			         .path("/{id}")
			         .resolveTemplate("id", 4)
			         .request(MediaType.APPLICATION_XML)
			         .delete(String.class);

			      String result = PASS;
			      if(!SUCCESS_RESULT.equals(callResult)){
			         result = FAIL;
			      }

			      System.out.println("Test case name: testDeleteProduct, Result: " + result );
			   }


	private void getAllProducts() {
     
		GenericType<List<Products>> list = new GenericType<List<Products>>() {};
	      List<Products> products = client
	         .target(REST_SERVICE_URL)
	         .request(MediaType.APPLICATION_XML)
	         .get(list);
	      String result = PASS;
	      if(products.isEmpty()){
	         result = FAIL;
	      }
	      System.out.println("Please find below all product details for this user");
	      System.out.print("\n");
	      for(Products usr:products)
	      {
	    	  System.out.println(usr);
	      }
	      System.out.println("Test case name: testGetAllProducts, Result: " + result );	
	}
		
	private void addProduct(){
		   
	      Form form = new Form();
	      form.param("product_name", "SONY_Led-32");
	      form.param("category_name", "Television");
	      form.param("price", "80000");
	      form.param("stock", "4");
	      form.param("remarks", "verygood");

	      String callResult = client
	         .target(REST_SERVICE_URL)
	         .request(MediaType.APPLICATION_XML)
	         .post(Entity.entity(form,
	            MediaType.APPLICATION_FORM_URLENCODED_TYPE),
	            String.class);
	   
	      String result = PASS;
	      if(!SUCCESS_RESULT.equals(callResult)){
	         result = FAIL;
	      }

	      System.out.println("addProduct, Result: " + result );
	   }
	   
	   private void updateProduct(){
		   Form form = new Form();
		   form.param("product_name", "DELL Inspiron");
		   form.param("category_name", "Laptop");
		   form.param("price", "40000");
		   form.param("stock", "7");
		   form.param("remarks", "awesome");
		   form.param("id", "4");
		   String callResult = client
			         .target(REST_SERVICE_URL)
			         .request(MediaType.APPLICATION_XML)
			         .put(Entity.entity(form,
			            MediaType.APPLICATION_FORM_URLENCODED_TYPE),
			            String.class);
			   
			      String result = PASS;
			      if(!SUCCESS_RESULT.equals(callResult)){
			         result = FAIL;
			      }

			      System.out.println("updateProduct, Result: " + result );
			   }

	}
