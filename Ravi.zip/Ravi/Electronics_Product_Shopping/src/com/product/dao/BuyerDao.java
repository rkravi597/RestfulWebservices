package com.product.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.product.entity.Products;

public class BuyerDao {

	public List<Products> getAllProducts() {

		List<Products> products = new ArrayList<Products>();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");//
		@SuppressWarnings("deprecation")
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Criteria criteria = session.createCriteria(Products.class);
		products = (List<Products>) criteria.list();
		return products;
	}


	public List<Products> getAllProductsforSpecificCategory(String name) {
		List<Products> products = new ArrayList<Products>();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");//
		@SuppressWarnings("deprecation")
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Products product=new Products();
		Query query = session.createQuery("from Products where category_name= :cname");
	    query.setString("cname", name);
		products = (List<Products>) query.list();
		return products;
	}


	public List<Products> getAllProductsPaginatedWithPrice(long l, long m) {
		List<Products> products = new ArrayList<Products>();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");//
		@SuppressWarnings("deprecation")
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Products product=new Products();
		Query query = session.createQuery("from Products where price>= :pstart and price<= :plast");
	    query.setLong("pstart", l);
	    query.setLong("plast", m);
		products = (List<Products>) query.list();
		Iterator iterator = products.iterator();
		
		while (iterator.hasNext()) {
			Products p = (Products) iterator.next();
			System.out.println(p.getProduct_name());
			System.out.println(p.getCategory_name());
			System.out.println(p.getPrice());
		}
		return products;
	}


	public int buyProducts(long id) {
		List<Products> products = new ArrayList<Products>();
		Configuration cfg = new Configuration();
		cfg.configure("hibernate.cfg.xml");//
		@SuppressWarnings("deprecation")
		SessionFactory factory = cfg.buildSessionFactory();
		Session session = factory.openSession();
		Transaction t = session.beginTransaction();
		Query query = session.createQuery("select count(stock) from Products where id= :pid");
	    query.setLong("pid", id);
	    Long count = (Long)query.uniqueResult();
        Query qry = session.createQuery("update Products set stock= :pstock where id= :pid");
        qry.setLong("pid", id);
        qry.setLong("pstock", count-1);
        int res = qry.executeUpdate();

		return res;
	}
	
	

}
