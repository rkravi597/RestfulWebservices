package com.product.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.product.entity.Products;

public class SellerDao {

	
	public long addProduct(Products product) {
		Configuration cfg=new Configuration();  
	    cfg.configure("hibernate.cfg.xml");//
	    @SuppressWarnings("deprecation")
		SessionFactory factory=cfg.buildSessionFactory();   
	    Session session=factory.openSession();  
	    Transaction t=session.beginTransaction();  
	    session.persist(product); 
	    long id=product.getId(); 
	    t.commit();
	    session.close();
	      return id;
	     
	}

	public long updateProduct(Products product, long pid) {
		Configuration cfg=new Configuration();  
	    cfg.configure("hibernate.cfg.xml");//
	    @SuppressWarnings("deprecation")
		SessionFactory factory=cfg.buildSessionFactory();   
	    Session session=factory.openSession();  
	    Transaction t=session.beginTransaction(); 
	    product.setId(pid);
	    session.saveOrUpdate(product);
	    t.commit();
	    session.close();
	    return pid;
	}

	public int removeProduct(long ppid) {
		Configuration cfg=new Configuration();  
	    cfg.configure("hibernate.cfg.xml");//
	    @SuppressWarnings("deprecation")
		SessionFactory factory=cfg.buildSessionFactory();   
	    Session session=factory.openSession();  
	    Transaction t=session.beginTransaction();  
	    Query qry = session.createQuery("delete from Product p where p.id= :pid");
        qry.setLong("pid", ppid);
        int res = qry.executeUpdate(); 
	    t.commit();
	    session.close();
	    return res;
	}

}
