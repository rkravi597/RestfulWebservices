package com.product.service;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.product.dao.BuyerDao;
import com.product.entity.Products;

@Path("/BuyerService")
public class buyerService {

	BuyerDao buyerDao=new BuyerDao();
	
	@GET
	@Path("/buyers")
	@Produces(MediaType.APPLICATION_XML)
	@Consumes(MediaType.APPLICATION_XML)
	public  List<Products> getAllProducts()
	{
	List<Products> products=new ArrayList<Products>();
	products=buyerDao.getAllProducts();
	return products;
	}
	
	
	@GET
	@Path("/buyers/{categoryName}")
	@Produces(MediaType.APPLICATION_XML)
	public List<Products> getproduct( @PathParam("categoryName") String name)
	{
		List<Products> products=new ArrayList<Products>();
		products=buyerDao.getAllProductsforSpecificCategory(name);
		return products;
	}
	
	@GET
	@Path("/buyers/{price1}/{price2}")
	@Produces(MediaType.APPLICATION_XML)
	public List<Products> getAllProductPaginated(@PathParam("price1") long l, @PathParam("price2") long m) 
	{
		List<Products> products=new ArrayList<Products>();
		products=buyerDao.getAllProductsPaginatedWithPrice(l,m);
		return products;
	}
	
	   @PUT
	   @Path("/buyers")
	   @Produces(MediaType.APPLICATION_XML)
	   public String buyProduct(@FormParam("id") int id)
	   {
		   int result=buyerDao.buyProducts(id);
		   if(result>0)
			{
			return "Thankyou for purchasing product";
			}
			
			return "Sorry,which product you choosed for purchasing is not avaliable now,please choose different products Thankyou!!";
	   }
}
