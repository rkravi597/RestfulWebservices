package com.product.service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.product.dao.BuyerDao;
import com.product.dao.SellerDao;
import com.product.entity.Products;

@Path("/{SellerService}")
public class sellerService {
	
	SellerDao sd= new SellerDao();
	BuyerDao bd=new BuyerDao();
@POST
@Path("/{products}")
@Produces(MediaType.APPLICATION_XML)
@Consumes(MediaType.APPLICATION_FORM_URLENCODED)

	public long addProduct(
			@FormParam("product_name") String product_name,
			@FormParam("category_name") String category_name,
			@FormParam("price") Double price,
	        @FormParam("stock") Long stock,
	        @FormParam("remarks") String remarks) throws IOException
{
	
	Products product=new Products(product_name,category_name,price,stock,remarks);
		  
		long id= sd.addProduct(product);
		
		if(id>0)
		{
			System.out.println("successfully  product saved");
		}
		else
		{
			System.out.println("oops somethings went wrong");
		}
		return id;
		
		
	}

@PUT
@Path("/{products}")
@Produces(MediaType.APPLICATION_XML)
@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
public Products updateProduct(
		@FormParam("product_name") String product_name,
		@FormParam("category_name") String category_name,
		@FormParam("price") Double price,
        @FormParam("stock") Long stock,
        @FormParam("remarks") String remarks,
        @FormParam("id") long id)throws IOException {
	
	Products product=new Products(product_name,category_name,price,stock,remarks);
   long uid= sd.updateProduct(product,id);
	
	if(uid>0)
	{
		System.out.println("successfully  product updated");
	}
	else
	{
		System.out.println("oops somethings went wrong");
	}
	return product;
}

@DELETE
@Path("/products/{id}")
@Produces(MediaType.APPLICATION_XML)
public void removeMesssage(@PathParam("id") int pid) {
	 int res= sd.removeProduct(pid);
		
		if(res>0)
		{
			System.out.println("successfully  product removed");
		}
		else
		{
			System.out.println("oops somethings went wrong");
		}
	
}
@GET
@Path("/products")
@Produces(MediaType.APPLICATION_XML)
@Consumes(MediaType.APPLICATION_XML)
public List<Products> getAllProducts()
{
List<Products> products=new ArrayList<Products>();
products=bd.getAllProducts();
return products;
}
}
