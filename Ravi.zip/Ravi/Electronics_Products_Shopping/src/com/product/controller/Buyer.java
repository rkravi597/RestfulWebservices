package com.product.controller;

import java.util.List;

import javax.ws.rs.BeanParam;
import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.product.bean.ProductFilterBean;
import com.product.entity.Product;
import com.product.service.buyerService;

@Path("/buyer")

public class Buyer {

	buyerService bs=new buyerService();
	
	@GET
	@Produces(MediaType.APPLICATION_XML)
	public List<Product> getProduct(@BeanParam ProductFilterBean filterBean)
	{
	
		
		if(filterBean.getStarting_price()>=0 && filterBean.getLast_price()>0)
		{
			return bs.getAllProductPaginated(filterBean.getStarting_price(), filterBean.getLast_price());
		}
		return bs.getAllProducts();
	}	
	@GET
    @Path("{starting_price}/{last_price}")
    @Produces(MediaType.APPLICATION_XML)
    public List<Product> getResultByPassingPriceRange(
                    @PathParam("starting_price") Long starting_price,
                    @PathParam("last_price") Long last_price) {
		return bs.getAllProductPaginated(starting_price, last_price);
        
    }
	@GET
	@Path("/{categoryName}")
	@Produces(MediaType.APPLICATION_XML)
	public List<Product> getproduct( @PathParam("categoryName") String name)
	{
		return bs.getProducts(name);
	}
	
	@PUT
	@Path("/{productId}")
	@Produces(MediaType.APPLICATION_XML)
	public String buyproduct( @PathParam("productId") long id)
	{
		int result=bs.buyProducts(id);
		if(result>0)
		{
		return "Thankyou for purchasing product";
		}
		
		return "Sorry,which product you choosed for purchasing is not avaliable now,please choose different products Thankyou!!";
	}
	
}
